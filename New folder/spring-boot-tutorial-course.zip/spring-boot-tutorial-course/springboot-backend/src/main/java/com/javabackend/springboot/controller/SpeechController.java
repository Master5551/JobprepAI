package com.javabackend.springboot.controller;

import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:3003")
public class SpeechController {

    @PostMapping("/summary")
    public String process(@RequestBody String data) {
        try {
            // Define the command to execute the Python script
            String pythonScript = "F:/Projects/JobPrepAI/AI_model/1.py";

            // Create ProcessBuilder instance with the command
            ProcessBuilder pb = new ProcessBuilder("python", pythonScript,data);

            // Start the process
            Process process = pb.start();

            // Read output from the process
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Wait for the process to finish
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                return output.toString();
            } else {
                return "Error: Python script execution failed";
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return "Error: Exception occurred";
        }
    }
}
